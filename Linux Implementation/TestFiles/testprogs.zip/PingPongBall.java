/** Used by BPingPong classes.
  */
public class PingPongBall implements java.io.Serializable
  { public long time; // For timing
    public byte[] data; // Payload for bandwidth estimates
  } // class PingPongBall
